window.onload = function() {

var next = document.querySelector('#next');
var back = document.querySelector('#previous');
var dots = document.querySelector('#dots');
var sliderImage = document.querySelector('#sliderImg');
var slide = 0;
var slideNumber = 0;

var menuButton = document.querySelector('#btn_menu');
var menu = document.querySelector('#menu');
var play = document.querySelector('#play');
var video = document.querySelector('video');


menuButton.onclick = function(){
	menu.classList.toggle('hg');
}

play.onclick = function(){
	play.style.zIndex = '5';
	video.play();
}

video.onclick = () => {
	if(video.play() == true){video.pause();}
	play.style.zIndex = '15';
};


for(let i = 1; i <= sliderImage.children.length; i++){
	let active = document.createElement('div');
	active.classList.add('dot');
	if(sliderImage.children[i - 1].classList.contains('active')){
		active.classList.add('active_dot');
	}
	dots.appendChild(active);
}

for(let i = 0; i < dots.children.length; i++){
	dots.children[i].addEventListener('click',() => {
		dotClick(i);
	});
}

function dotClick(element){
	slideNumber = element;
	slide = 100 * element;
	moveSlider(slide,slideNumber);
	changeActiveDot(element);	
}

function changeActiveDot(dot){
	for(item of dots.children){
		item.classList.remove('active_dot');
	}
	dots.children[dot].classList.add('active_dot')
}

function moveSlider(slide_n,slideNumber_n){
	if((slideNumber_n < (sliderImage.children.length)) && (slideNumber_n >= 0)){
		sliderImage.style.transform = 'translate(-'+slide_n+'%, 0)';
		changeActiveDot(slideNumber_n);
	}
}

next.addEventListener('click',(event) => {
	if(slide < (sliderImage.children.length - 1)*100){
		slide += 100;
		slideNumber++;
		moveSlider(slide,slideNumber);
	} else {
		slide = 0;
		slideNumber = 0;
		moveSlider(slide,slideNumber);		
	} 
	event.preventDefault();
});


back.addEventListener('click',(event) => {
	if(slide > 0){
		slide -= 100;
		slideNumber--;
		moveSlider(slide,slideNumber);
	} else {
		slide = 100 * (sliderImage.children.length - 1);
		slideNumber = sliderImage.children.length - 1;
		moveSlider(slide,slideNumber);		
	} 	
	event.preventDefault();
});

}